#!/bin/bash

./energiminer stratum://EKMtQQcuh1cYXdmuaAozR6zogSt6JTBjzL.RigName@euro.nrg.minecrypto.pro:9999 -G --response-timeout 10 --farm-recheck 1000 --cl-local-work 256

# For CUDA:
#  -U
# For OpenCL:
#  -G
