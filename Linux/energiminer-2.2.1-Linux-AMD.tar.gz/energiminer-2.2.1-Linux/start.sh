#!/bin/bash

./energiminer stratum://Weblogin.WorkerName:WorkerPassword@stratum.nrg.minecrypto.pro:9999 -G --response-timeout 10 --cl-local-work 256

