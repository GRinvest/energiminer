#!/bin/bash

./energiminer stratum://Weblogin.WorkerName:WorkerPassword@stratum.nrg.minecrypto.pro:9999 -U --response-timeout 10 --cuda-parallel-hash 8 --cuda-block-size 256

